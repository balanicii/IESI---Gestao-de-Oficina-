-- ============================================================================
-- IESI | SISTEMA DE GESTAO DE UMA PEQUENA OFICINA
-- MySQL Workbench / MySQL 8.0+
-- 7 tabelas, de acordo com o diagrama de dados simplificado (modo claro).
-- Inclui: criacao da BD, tabelas, chaves, dados ficticios, consultas e procedures.
-- Oficina ficticia: 10 funcionarios (inclui gerente e tecnico), 5 maquinas.
--
-- INSTRUCOES: abrir este ficheiro no MySQL Workbench e executar o script.
-- Seguranca: NAO apaga bases de dados nem tabelas existentes.
-- Se voltares a executar, os dados de exemplo com IDs ja existentes nao
-- serao inseridos novamente. As procedures demonstrativas sao recriadas.
-- ============================================================================

-- PARTE 1 | CRIAR A BASE DE DADOS --------------------------------------------
CREATE DATABASE IF NOT EXISTS iesi_oficina
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE iesi_oficina;

-- PARTE 2 | CRIAR AS 7 TABELAS ------------------------------------------------

-- Funcionarios da oficina, incluindo gerente e tecnico de manutencao.
-- O campo perfil representa o nivel de acesso (nao e uma tabela separada).
CREATE TABLE IF NOT EXISTS Funcionario (
    idFuncionario INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL,
    cargo VARCHAR(80) NOT NULL,
    perfil ENUM('gerente', 'funcionario', 'tecnico') NOT NULL,
    CONSTRAINT pk_funcionario PRIMARY KEY (idFuncionario),
    CONSTRAINT uq_funcionario_email UNIQUE (email)
) ENGINE = InnoDB;

-- As cinco maquinas da oficina.
CREATE TABLE IF NOT EXISTS Maquina (
    idMaquina INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    estado ENUM('operacional', 'avariada', 'manutencao') NOT NULL,
    localizacao VARCHAR(80) NOT NULL,
    CONSTRAINT pk_maquina PRIMARY KEY (idMaquina)
) ENGINE = InnoDB;

-- Cada horario associa UM funcionario a UMA maquina num intervalo de tempo.
-- Um funcionario/maquina pode aparecer em varios horarios (relacoes 1:N).
CREATE TABLE IF NOT EXISTS Horario (
    idHorario INT NOT NULL AUTO_INCREMENT,
    dataInicio DATETIME NOT NULL,
    dataFim DATETIME NOT NULL,
    idFuncionario INT NOT NULL,
    idMaquina INT NOT NULL,
    CONSTRAINT pk_horario PRIMARY KEY (idHorario),
    CONSTRAINT fk_horario_funcionario FOREIGN KEY (idFuncionario)
        REFERENCES Funcionario(idFuncionario),
    CONSTRAINT fk_horario_maquina FOREIGN KEY (idMaquina)
        REFERENCES Maquina(idMaquina),
    CONSTRAINT chk_horario_periodo CHECK (dataFim > dataInicio)
) ENGINE = InnoDB;

-- Avarias comunicadas por funcionarios e associadas as maquinas.
CREATE TABLE IF NOT EXISTS Avaria (
    idAvaria INT NOT NULL AUTO_INCREMENT,
    dataRegisto DATE NOT NULL,
    descricao TEXT NOT NULL,
    estado ENUM('aberta', 'resolvida') NOT NULL,
    idFuncionario INT NOT NULL,
    idMaquina INT NOT NULL,
    CONSTRAINT pk_avaria PRIMARY KEY (idAvaria),
    CONSTRAINT fk_avaria_funcionario FOREIGN KEY (idFuncionario)
        REFERENCES Funcionario(idFuncionario),
    CONSTRAINT fk_avaria_maquina FOREIGN KEY (idMaquina)
        REFERENCES Maquina(idMaquina)
) ENGINE = InnoDB;

-- Manutencoes de maquinas feitas pelo funcionario com perfil de tecnico.
-- idTecnico e uma chave externa para Funcionario, nao uma tabela nova.
CREATE TABLE IF NOT EXISTS Manutencao (
    idManutencao INT NOT NULL AUTO_INCREMENT,
    data DATE NOT NULL,
    tipo ENUM('preventiva', 'corretiva') NOT NULL,
    descricao TEXT NOT NULL,
    idMaquina INT NOT NULL,
    idTecnico INT NOT NULL,
    CONSTRAINT pk_manutencao PRIMARY KEY (idManutencao),
    CONSTRAINT fk_manutencao_maquina FOREIGN KEY (idMaquina)
        REFERENCES Maquina(idMaquina),
    CONSTRAINT fk_manutencao_tecnico FOREIGN KEY (idTecnico)
        REFERENCES Funcionario(idFuncionario)
) ENGINE = InnoDB;

-- Ferramentas e consumiveis numa so tabela: apenas controlo das quantidades.
CREATE TABLE IF NOT EXISTS ArtigoStock (
    idArtigo INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(120) NOT NULL,
    tipo ENUM('ferramenta', 'consumivel') NOT NULL,
    quantidade INT NOT NULL DEFAULT 0,
    stockMinimo INT NOT NULL DEFAULT 0,
    CONSTRAINT pk_artigo_stock PRIMARY KEY (idArtigo),
    CONSTRAINT uq_artigo_stock_nome UNIQUE (nome),
    CONSTRAINT chk_artigo_quantidade CHECK (quantidade >= 0),
    CONSTRAINT chk_artigo_minimo CHECK (stockMinimo >= 0)
) ENGINE = InnoDB;

-- Encomendas simples: cada registo repoe um artigo.
-- Nao existe requisicao/entrega individual a funcionarios.
CREATE TABLE IF NOT EXISTS Encomenda (
    idEncomenda INT NOT NULL AUTO_INCREMENT,
    data DATE NOT NULL,
    quantidade INT NOT NULL,
    fornecedor VARCHAR(120) NOT NULL,
    idArtigo INT NOT NULL,
    CONSTRAINT pk_encomenda PRIMARY KEY (idEncomenda),
    CONSTRAINT fk_encomenda_artigo FOREIGN KEY (idArtigo)
        REFERENCES ArtigoStock(idArtigo),
    CONSTRAINT chk_encomenda_quantidade CHECK (quantidade > 0)
) ENGINE = InnoDB;

-- PARTE 3 | DADOS FICTICIOS PARA TESTES ---------------------------------------
-- INSERT IGNORE: evita repetir IDs ja inseridos numa segunda execucao.
-- Estes dados sao ficticios e podem ser adaptados ao relatorio.

INSERT IGNORE INTO Funcionario
    (idFuncionario, nome, email, cargo, perfil) VALUES
    (1, 'Carlos Martins', 'carlos@oficina.exemplo', 'Gerente', 'gerente'),
    (2, 'Sofia Costa', 'sofia@oficina.exemplo', 'Tecnica de manutencao', 'tecnico'),
    (3, 'Ana Silva', 'ana@oficina.exemplo', 'Operadora', 'funcionario'),
    (4, 'Bruno Reis', 'bruno@oficina.exemplo', 'Operador', 'funcionario'),
    (5, 'Diana Lopes', 'diana@oficina.exemplo', 'Operadora', 'funcionario'),
    (6, 'Eduardo Pinto', 'eduardo@oficina.exemplo', 'Operador', 'funcionario'),
    (7, 'Ines Rocha', 'ines@oficina.exemplo', 'Operadora', 'funcionario'),
    (8, 'Joao Ferreira', 'joao@oficina.exemplo', 'Operador', 'funcionario'),
    (9, 'Luis Martins', 'luis@oficina.exemplo', 'Operador', 'funcionario'),
    (10, 'Marta Gomes', 'marta@oficina.exemplo', 'Operadora', 'funcionario');

INSERT IGNORE INTO Maquina
    (idMaquina, nome, estado, localizacao) VALUES
    (1, 'Torno CNC 01', 'operacional', 'Zona A'),
    (2, 'Fresadora 02', 'operacional', 'Zona A'),
    (3, 'Prensa 03', 'manutencao', 'Zona B'),
    (4, 'Berbequim de coluna 04', 'operacional', 'Zona B'),
    (5, 'Serra 05', 'operacional', 'Zona C');

-- Turno 08:00-17:00, com almoco ilustrativo das 12:00 as 13:00.
INSERT IGNORE INTO Horario
    (idHorario, dataInicio, dataFim, idFuncionario, idMaquina) VALUES
    (1, '2026-11-03 08:00:00', '2026-11-03 12:00:00', 3, 1),
    (2, '2026-11-03 08:00:00', '2026-11-03 12:00:00', 4, 2),
    (3, '2026-11-03 08:00:00', '2026-11-03 12:00:00', 5, 4),
    (4, '2026-11-03 08:00:00', '2026-11-03 12:00:00', 6, 5),
    (5, '2026-11-03 13:00:00', '2026-11-03 17:00:00', 7, 1),
    (6, '2026-11-03 13:00:00', '2026-11-03 17:00:00', 8, 2),
    (7, '2026-11-03 13:00:00', '2026-11-03 17:00:00', 9, 4),
    (8, '2026-11-03 13:00:00', '2026-11-03 17:00:00', 10, 5);

INSERT IGNORE INTO Avaria
    (idAvaria, dataRegisto, descricao, estado, idFuncionario, idMaquina) VALUES
    (1, '2026-11-02', 'Falha no sensor de seguranca da prensa.', 'aberta', 5, 3),
    (2, '2026-10-22', 'Vibracao excessiva na fresadora.', 'resolvida', 4, 2);

INSERT IGNORE INTO Manutencao
    (idManutencao, data, tipo, descricao, idMaquina, idTecnico) VALUES
    (1, '2026-10-23', 'corretiva', 'Aperto e substituicao de componente na fresadora.', 2, 2),
    (2, '2026-11-03', 'corretiva', 'Diagnostico da prensa (intervencao agendada).', 3, 2),
    (3, '2026-11-06', 'preventiva', 'Revisao prevista do torno CNC.', 1, 2);

INSERT IGNORE INTO ArtigoStock
    (idArtigo, nome, tipo, quantidade, stockMinimo) VALUES
    (1, 'Pregos 40 mm', 'consumivel', 80, 100),
    (2, 'Parafusos M6', 'consumivel', 300, 120),
    (3, 'Chave de fendas', 'ferramenta', 6, 2),
    (4, 'Alicate universal', 'ferramenta', 4, 2),
    (5, 'Fita metrica', 'ferramenta', 8, 3),
    (6, 'Luvas de protecao', 'consumivel', 12, 15);

INSERT IGNORE INTO Encomenda
    (idEncomenda, data, quantidade, fornecedor, idArtigo) VALUES
    (1, '2026-11-02', 200, 'Fornecedor Exemplo', 1),
    (2, '2026-10-28', 10, 'Fornecedor Exemplo', 6);

-- PARTE 4 | CONSULTAS PRINCIPAIS: PROCEDIMENTOS ARMAZENADOS -------------------
-- O enunciado pede algumas consultas implementadas com stored procedures.
DELIMITER $$

DROP PROCEDURE IF EXISTS sp_ListarFuncionarios$$
CREATE PROCEDURE sp_ListarFuncionarios()
BEGIN
    SELECT idFuncionario, nome, cargo, perfil
    FROM Funcionario
    ORDER BY nome;
END$$

DROP PROCEDURE IF EXISTS sp_HorariosPorDia$$
CREATE PROCEDURE sp_HorariosPorDia(IN pDia DATE)
BEGIN
    SELECT f.nome AS funcionario, m.nome AS maquina,
           h.dataInicio, h.dataFim
    FROM Horario AS h
    JOIN Funcionario AS f ON f.idFuncionario = h.idFuncionario
    JOIN Maquina AS m ON m.idMaquina = h.idMaquina
    WHERE DATE(h.dataInicio) = pDia
    ORDER BY h.dataInicio, m.nome;
END$$

DROP PROCEDURE IF EXISTS sp_ListarMaquinas$$
CREATE PROCEDURE sp_ListarMaquinas()
BEGIN
    SELECT idMaquina, nome, estado, localizacao
    FROM Maquina
    ORDER BY idMaquina;
END$$

DROP PROCEDURE IF EXISTS sp_HistoricoManutencoes$$
CREATE PROCEDURE sp_HistoricoManutencoes()
BEGIN
    SELECT m.nome AS maquina, f.nome AS tecnico,
           t.data, t.tipo, t.descricao
    FROM Manutencao AS t
    JOIN Maquina AS m ON m.idMaquina = t.idMaquina
    JOIN Funcionario AS f ON f.idFuncionario = t.idTecnico
    ORDER BY t.data DESC;
END$$

DROP PROCEDURE IF EXISTS sp_StockBaixo$$
CREATE PROCEDURE sp_StockBaixo()
BEGIN
    SELECT idArtigo, nome, tipo, quantidade, stockMinimo
    FROM ArtigoStock
    WHERE quantidade < stockMinimo
    ORDER BY nome;
END$$

DROP PROCEDURE IF EXISTS sp_ListarEncomendas$$
CREATE PROCEDURE sp_ListarEncomendas()
BEGIN
    SELECT e.idEncomenda, e.data, a.nome AS artigo,
           e.quantidade, e.fornecedor
    FROM Encomenda AS e
    JOIN ArtigoStock AS a ON a.idArtigo = e.idArtigo
    ORDER BY e.data DESC;
END$$

DELIMITER ;

-- PARTE 5 | EXEMPLOS DE TESTE -------------------------------------------------
-- Se quiseres ver resultados no Workbench, seleciona estas linhas e executa-as.
CALL sp_ListarFuncionarios();
CALL sp_HorariosPorDia('2026-11-03');
CALL sp_ListarMaquinas();
CALL sp_HistoricoManutencoes();
CALL sp_StockBaixo();
CALL sp_ListarEncomendas();

-- Verificar que ficaram criadas as sete tabelas:
SHOW TABLES;

-- NOTAS DE ALCANCE -----------------------------------------------------------
-- 1. O esquema reproduz as tabelas e as relacoes do diagrama draw.io.
-- 2. O login/password do mockup ainda nao foi implementado (nao consta
--    do diagrama). O campo perfil so representa o tipo de utilizador.
-- 3. As verificacoes de permissoes, conflitos de horarios, pausas de almoco,
--    e se idTecnico tem o perfil 'tecnico' ficam para a aplicacao.
-- 4. As encomendas NAO alteram automaticamente a quantidade em stock;
--    o gerente atualiza o stock quando os artigos sao recebidos.
-- 5. Este script e para MySQL 8.0+; nao e um ficheiro de projeto .mwb.
